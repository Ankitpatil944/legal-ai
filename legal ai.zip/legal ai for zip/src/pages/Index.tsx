import { useState, useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { TopNav } from "@/components/layout/top-nav";
import { ThemeProvider } from "@/components/theme/theme-provider";
import { UploadPanel } from "@/components/dashboard/upload-panel";
import { DocumentViewer } from "@/components/dashboard/document-viewer";
import { AnalyticsPanel } from "@/components/dashboard/analytics-panel";
import { RisksPanel } from "@/components/dashboard/risks-panel";
import { SuggestionsPanel } from "@/components/dashboard/suggestions-panel";
import { SummaryPanel } from "@/components/dashboard/summary-panel";
import { motion, AnimatePresence } from "framer-motion";

const Index = () => {
  const [activeTab, setActiveTab] = useState<string>("#upload");
  const [isLoading, setIsLoading] = useState(true);
  const [analysis, setAnalysis] = useState(null);
  
  // Effect for the initial page load animation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Handle tab changes from sidebar
  useEffect(() => {
    // Get the hash from URL when it changes
    const handleHashChange = () => {
      const hash = window.location.hash || "#upload";
      setActiveTab(hash);
    };
    
    // Set initial hash
    handleHashChange();
    
    // Listen for hash changes
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Render loading animation
  if (isLoading) {
    return (
      <ThemeProvider>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <motion.div
              animate={{ 
                rotate: [0, 360],
                scale: [1, 1.2, 1],
              }}
              transition={{ 
                repeat: Infinity,
                duration: 1.5,
                ease: "easeInOut"
              }}
              className="mx-auto mb-4 w-16 h-16 rounded-full bg-gradient-to-r from-accent to-primary flex items-center justify-center"
            >
              <div className="w-12 h-12 rounded-full bg-background flex items-center justify-center">
                <span className="text-xl font-bold text-primary">LA</span>
              </div>
            </motion.div>
            <motion.h1
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="text-2xl font-heading font-bold"
            >
              LegalAI
            </motion.h1>
          </motion.div>
        </div>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar activeItem={activeTab} setActiveItem={setActiveTab} />
        
        <div className="flex-1 flex flex-col">
          <TopNav />
          
          <main className="flex-1 p-4 md:p-6 overflow-y-auto bg-background/95 backdrop-blur-sm">
            <div className="max-w-7xl mx-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="animate-page-transition"
                >
                  {activeTab === "#upload" && (
                    <>
                      <h1 className="text-2xl md:text-3xl font-heading font-bold mb-6">Document Upload</h1>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-1">
                          <UploadPanel onAnalysis={setAnalysis} />
                        </div>
                        <div className="lg:col-span-2">
                          <DocumentViewer analysis={analysis} />
                        </div>
                      </div>
                      <div className="mt-6">
                        <AnalyticsPanel analysis={analysis} />
                      </div>
                    </>
                  )}
                  
                  {activeTab === "#review" && (
                    <>
                      <h1 className="text-2xl md:text-3xl font-heading font-bold mb-6">Document Review</h1>
                      <DocumentViewer analysis={analysis} />
                      <div className="mt-6">
                        <AnalyticsPanel analysis={analysis} />
                      </div>
                    </>
                  )}
                  
                  {activeTab === "#risks" && (
                    <>
                      <h1 className="text-2xl md:text-3xl font-heading font-bold mb-6">Risk Analysis</h1>
                      <RisksPanel analysis={analysis} />
                    </>
                  )}
                  
                  {activeTab === "#suggestions" && (
                    <>
                      <h1 className="text-2xl md:text-3xl font-heading font-bold mb-6">AI Suggestions</h1>
                      <SuggestionsPanel analysis={analysis} />
                    </>
                  )}
                  
                  {activeTab === "#summary" && (
                    <>
                      <h1 className="text-2xl md:text-3xl font-heading font-bold mb-6">Document Summary</h1>
                      <SummaryPanel analysis={analysis} />
                    </>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          </main>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default Index;
